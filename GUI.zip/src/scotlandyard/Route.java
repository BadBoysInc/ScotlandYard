package scotlandyard;

public enum Route {
  Taxi, Bus, Underground, Boat
}
