package scotlandyard;

public enum Colour {
  Black, Blue, Green, Red, White, Yellow
}
