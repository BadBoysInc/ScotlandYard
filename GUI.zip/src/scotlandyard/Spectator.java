package scotlandyard;

public interface Spectator {
  void notify(Move move);
}
