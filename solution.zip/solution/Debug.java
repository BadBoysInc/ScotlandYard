package solution;

public class Debug {
	//Enable debug logging.
	public static final boolean debug = false;
	
}
