package solution;

public class ScotlandYardApplication {
	
	//Start the game.
	public static void main(String[] args) {
		Presenter p = new Presenter();
	}
	
}
